package com.joy.kalkulator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText ang1, ang2;
    TextView hasilnya;
    Toast toast;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ang1 =(EditText) findViewById(R.id.angka1);
        ang2 =(EditText) findViewById(R.id.angka2);
        hasilnya =(TextView) findViewById(R.id.hasil);
    }

    public void tambah(View view) {
        try{
            int a1=Integer.parseInt(ang1.getText().toString());
            int a2=Integer.parseInt(ang2.getText().toString());
            Integer hsl = a1+a2;
            hasilnya.setText(hsl.toString());
            toast = Toast.makeText(this, "Perhitungan berhasil!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 150);
            toast.show();
        }catch (Exception e){
            Log.e("Error", String.valueOf(e));
            hasilnya.setText("null");
            toast = Toast.makeText(getApplicationContext(), "Input masih kosong!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 150);
            toast.show();
        }
    }

    public void kurang(View view) {
        try{
            int a1=Integer.parseInt(ang1.getText().toString());
            int a2=Integer.parseInt(ang2.getText().toString());
            Integer hsl = a1-a2;
            hasilnya.setText(hsl.toString());
            toast = Toast.makeText(this, "Perhitungan berhasil!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 150);
            toast.show();
        }catch (Exception e){
            Log.e("Error", String.valueOf(e));
            hasilnya.setText("null");
            toast = Toast.makeText(getApplicationContext(), "Input masih kosong!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 150);
            toast.show();
        }
    }

    public void kali(View view) {
        try{
            int a1=Integer.parseInt(ang1.getText().toString());
            int a2=Integer.parseInt(ang2.getText().toString());
            Integer hsl = a1*a2;
            hasilnya.setText(hsl.toString());
            toast = Toast.makeText(this, "Perhitungan berhasil!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 150);
            toast.show();
        }catch (Exception e){
            Log.e("Error", String.valueOf(e));
            hasilnya.setText("null");
            toast = Toast.makeText(getApplicationContext(), "Input masih kosong!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 150);
            toast.show();
        }
    }

    public void bagi(View view) {
        try{
            Double a1=Double.parseDouble(ang1.getText().toString());
            Double a2=Double.parseDouble(ang2.getText().toString());
            Double hsl = a1/a2;
            hasilnya.setText(hsl.toString());
            toast = Toast.makeText(this, "Perhitungan berhasil!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 150);
            toast.show();
        }catch (Exception e){
            Log.e("Error", String.valueOf(e));
            hasilnya.setText("null");
            toast = Toast.makeText(getApplicationContext(), "Input masih kosong!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, 150);
            toast.show();
        }
    }
}