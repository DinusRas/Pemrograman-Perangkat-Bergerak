package com.decii.kuliner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recKuliner;
    private ArrayList<Kuliner> listKuliner;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        recKuliner = findViewById(R.id.rec_kuliner);
        initData();

        recKuliner.setAdapter(new KulinerAdapter(listKuliner));
        recKuliner.setLayoutManager(new LinearLayoutManager(this));
    }
    
    private void initData(){
        this.listKuliner = new ArrayList<>();
        listKuliner.add(new Kuliner ("Angkringan Polke",
                "Jl. Pamularsih Raya, Semarang",
                "Angkringan paling polke di Semarang",
                R.drawable.bandeng));

        listKuliner.add(new Kuliner("Soto Pak No",
                "Jl. Prof Dr. Hamka, Semarang",
                "Soto paling wenak gaada obat",
                R.drawable.soto));

        listKuliner.add(new Kuliner("Rendang Nendang",
                "Jl. Beringin, Semarang",
                "Rendang paling menendang",
                R.drawable.rendang));
        
        listKuliner.add(new Kuliner("Sate Cak Herman",
                "Jl. Depan BPI, Semarang",
                "Sate kebal kebul",
                R.drawable.sate));
    }
}